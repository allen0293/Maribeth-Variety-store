<?php
//session_set_cookie_params(0);
session_start();
if(!$_SESSION['username']){
	header('Location: login.php');
}
?>
